package com.example.radiobuttonpr;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioButton rdb1, rdb2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rdb1 = findViewById(R.id.rb1);
        rdb2 = findViewById(R.id.rb2);
    }
    public void response(View view){
        if(rdb1.isChecked()){
            Toast.makeText(this, "Male", Toast.LENGTH_SHORT).show();
        }
        if(rdb2.isChecked()){
            Toast.makeText(this, "Female", Toast.LENGTH_SHORT).show();
        }
    }
}