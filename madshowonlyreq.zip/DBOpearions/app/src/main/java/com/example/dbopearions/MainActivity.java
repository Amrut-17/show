package com.example.dbopearions;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText name, contact, dob;
    Button insert, update, delete, show;
    DBHelper DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.name);
        contact = findViewById(R.id.contact);
        dob = findViewById(R.id.dob);

        insert = findViewById(R.id.insertbtn);
        update = findViewById(R.id.updatebtn);
        delete = findViewById(R.id.deletebtn);
        show = findViewById(R.id.viewdata);

        DB = new DBHelper(this);

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = name.getText().toString();
                String contactTXT = contact.getText().toString();
                String dobTXT = dob.getText().toString();

                Boolean checkInsertData = DB.insertUserData(nameTXT, contactTXT, dobTXT);
                if(checkInsertData){
                    Toast.makeText(MainActivity.this, "Data Inserted Successfully", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this, "Insertion Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });


        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = name.getText().toString();
                String contactTXT = contact.getText().toString();
                String dobTXT = dob.getText().toString();

                Boolean checkUpdateData = DB.updatetUserData(nameTXT, contactTXT, dobTXT);
                if(checkUpdateData){
                    Toast.makeText(MainActivity.this, "Data Updated Successfully", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this, "Updating Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });


        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = name.getText().toString();
                String contactTXT = contact.getText().toString();
                String dobTXT = dob.getText().toString();

                Boolean deleteData = DB.deleteUserData(nameTXT);
                if(deleteData){
                    Toast.makeText(MainActivity.this, "Data DELETED Successfully", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this, "DELETION Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });


        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor result = DB.showUserData();
                if(result.getCount() == 0){
                    Toast.makeText(MainActivity.this, "No Entry Exist", Toast.LENGTH_SHORT).show();
                    return;
                }

                StringBuffer str = new StringBuffer();
                while(result.moveToNext()){
                    str.append("Name : " + result.getString(0) + "\n");
                    str.append("Contact : " + result.getString(1) + "\n");
                    str.append("DOB : " + result.getString(2) + "\n \n");
                }

                AlertDialog.Builder build = new AlertDialog.Builder(MainActivity.this);
                build.setCancelable(true);
                build.setTitle("User Entry");
                build.setMessage(str.toString());
                build.show();
            }
        });
    }
}