package com.example.messagepr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button btn;
    EditText e1, e2;

    String num, desc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1 = findViewById(R.id.et1);
        e2 = findViewById(R.id.et2);
        btn = findViewById(R.id.btn1);

        btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                sendSMS();            }
        });
    }
    public void sendSMS(){
        num = e1.getText().toString();
        desc = e2.getText().toString();

        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.fromParts("sms", num, null));
        intent.putExtra("sms_body", desc);
        startActivity(intent);
    }

}