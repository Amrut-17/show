package com.example.checkboxpr;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    CheckBox ch1, ch2, ch3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ch1 = findViewById(R.id.ch1);
        ch2 = findViewById(R.id.ch2);
        ch3 = findViewById(R.id.ch3);
    }

    public void checkedItems(View view){
        String selectedItems = "";
        int totalAmount = 0;

        if(ch1.isChecked()){
            selectedItems += " Pizza, ";
            totalAmount += 100;
        }
        if(ch2.isChecked()){
            selectedItems += " Burger, ";
            totalAmount += 55;
        }
        if(ch3.isChecked()){
            selectedItems += "Nuggets";
            totalAmount += 90;
        }

        Toast.makeText(this, "Selected Items : " + selectedItems + " \n TOTAL_AMOUNT :" + totalAmount, Toast.LENGTH_SHORT).show();
    }
}