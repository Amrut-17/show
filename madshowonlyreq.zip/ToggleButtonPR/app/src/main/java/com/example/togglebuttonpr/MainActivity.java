package com.example.togglebuttonpr;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    ToggleButton tb1;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tb1 = findViewById(R.id.tgb);
        tv = findViewById(R.id.tv1);

    }

    public void onToggle(View view){
        if(tb1.isChecked()){
            tv.setText("Toggle is ON");
        }else{
            tv.setText("Toggle is OFF");
        }
    }
}