package com.example.broadcastpr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    AirplaneModeChangeRec airplaneModeChangeRec = new AirplaneModeChangeRec();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        registerReceiver(airplaneModeChangeRec, filter);
    }

    public void onStop(){
        super.onStop();
        unregisterReceiver(airplaneModeChangeRec);
    }
}