package com.example.broadcastpr;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.widget.Toast;

public class AirplaneModeChangeRec extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent){
        if(airplaneModeOn(context.getApplicationContext())){
            Toast.makeText(context, "Airplane Mode is On", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(context, "Airplane Mode is Off", Toast.LENGTH_SHORT).show();
        }
    }

    public Boolean airplaneModeOn(Context contect){
        return Settings.System.getInt(contect.getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0)!=0;
    }
}
